This is term project of Embedded Software class in CNU.
We're extending SLOS OS.

Team: (02) 유종민, 남대환


